//
//  main.m
//  PayPal-iOS-SDK-Sample-App
//
//  Copyright (c) 2014 PayPal. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZZAppDelegate.h"

int main(int argc, char *argv[]) {
  @autoreleasepool {
    return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZZAppDelegate class]));
  }
}
